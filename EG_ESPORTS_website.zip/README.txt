EG ESPORTS website

1. Open index.html in a browser to preview the site.
2. Replace the sample "Player Name" entries with your real roster.
3. Add your official Instagram/YouTube/WhatsApp links where you want them.
4. The Join form is a front-end demo: it copies an application summary, but does not send it to a server.
5. To publish, upload index.html to a static host such as GitHub Pages, Netlify, or your hosting provider.
